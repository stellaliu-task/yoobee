How to run it:
=====================================================================
1.	Install Flask (just run pip install flask in VS Code terminal)
2.	Start the server with python app.py
3.	Open your browser to: http://localhost:5000
=====================================================================
Test account:
•	Email: test13@example.com
•	Password: test123
(Or register a new account)
=====================================================================
Admin login:
•	Email: admin@premiumrentals.com
•	Password: securepassword123

